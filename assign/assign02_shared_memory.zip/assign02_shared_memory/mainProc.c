#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/shm.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include "ipcEx.h"


int main(int argc, char** argv)
{

  /* Print out usage statement when no value is specified */
  if (argc != 2) {
    printf("You must specify an integer value as an argument\n");
    return 1;
  }


  // TODO:
  // Insert your code here (most of it, anyway).
  // Print the contents of the shared buffer down below.




  // NOTE: Do NOT remove the following line, it is used
  // by the included units tests
  // You MAY change it's level of indentation if you
  // wrap it in curly braces for any reason
  printf("============= Buffer start =============\n");


  // //////////////////////////////////////
  // TODO:
  // Print the contents of the shared buffer here, between the
  // provided "Buffer start" and "Buffer end" print statements.
  // //////////////////////////////////////


  // NOTE: Do NOT remove the following line, it is used
  // by the included units tests
  // You MAY change it's level of indentation if you
  // wrap it in curly braces for any reason
  printf("============= Buffer end ===============\n");


  return 0;
}

