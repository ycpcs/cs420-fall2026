#ifndef _sem_name_h
#define _sem_name_h

// *** STUDENTS: Define your semaphore name below before compiling ***
// #define YCP_USER_NAME "YOUR_YCP_USERNAME"

#ifndef YCP_USER_NAME
    #error YCP_USER_NAME is not defined! Open sem_name.h and both uncomment and define the YCP_USER_NAME value with your YCP user name (line 5).
    #define PP_SEM_NAME ""
#else
    #define PP_SEM_NAME YCP_USER_NAME
#endif

const char* SEM_NAME = PP_SEM_NAME;

#endif